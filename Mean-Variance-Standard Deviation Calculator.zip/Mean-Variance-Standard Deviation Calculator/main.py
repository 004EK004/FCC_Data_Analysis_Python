from mean_var_std import calculate
from unittest import main

# Test your function here
print(calculate([0,1,2,3,4,5,6,7,8]))

# Run unit tests automatically
main(module='test_module', exit=False)